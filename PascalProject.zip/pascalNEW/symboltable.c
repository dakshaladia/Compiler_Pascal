#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TableLength 30

typedef struct node{
	char dtype[10];
	char rtype[10];
	char name[10];
	char scope;
	int type; 
int colno;
int rowwno;
	struct node* next;
}Node;

Node* Table[TableLength]; 	

void Initialize(){
	for (int i = 0; i < TableLength; ++i)
	{
		Table[i] = NULL;
	}
}

char* show(int type){
	if(type == 0)
		return "Identifier";
	else
		return "Function";
}

void display()
{
	//printf("L is local, G is global, N is none\n\n");
	printf("<Name, \tReturn type, \tData type, \tType, \tScope >\n");
	for(int i = 0; i < TableLength; i++) {
		Node *temp = Table[i];
		while(temp) {
			printf("<%s,\t %s,\t %s,\t %s,\t %c>\n",temp->name,temp->rtype,temp->dtype,show(temp->type), temp->scope);
			temp = temp->next;
		}
	}
}

int hash_function(char *str) 
{
	unsigned long hash = 612;
	int c;	
	while(c = *str++) 
		hash  = hash*19 + c;

	return hash % TableLength;
}


int search(char *str)
{
	unsigned long hash_address = hash_function(str);
	Node *temp = Table[hash_address];

	while(temp) {
		if(strcmp(temp->name,str) == 0)
			return 1;
		temp = temp->next;
	}
	
	return 0;
}

void insert(Node* n)
{

	//printf("Inserting %s\n", n->name);
	//fflush(stdout);
	if(n->type == 0) 		
		strcpy(n->rtype,"--");
	else{					
		strcpy(n->dtype,"--");
		n->scope = 'G';
	}


	if(search(n->name))
		return;

	unsigned long hash_address = hash_function(n->name);
	
	hash_address = hash_address % 30;			
	
	
	n->next = NULL;
	
	
	if(Table[hash_address] == NULL) 
		Table[hash_address] = n;	
	
	else {
		Node *temp = Table[hash_address];
		
		while(temp->next != NULL) 
			temp = temp->next;
		
		temp->next = n;
	
	}
}

